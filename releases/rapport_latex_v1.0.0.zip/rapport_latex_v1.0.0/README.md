# Latex


### compiling glossary / acronyms

`pdflatex main.tex`

`makeglossaries main`

`pdflatex main.tex`
